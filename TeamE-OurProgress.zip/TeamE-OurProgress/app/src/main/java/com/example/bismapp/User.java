package com.example.bismapp;

public class User {
    private String id;

    public User() {
    }

    public User(String id) {
        this.id = id;
    }

}
